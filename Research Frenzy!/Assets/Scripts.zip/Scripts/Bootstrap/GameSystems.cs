﻿namespace Bootstrap
{
    /// <summary>
    /// Container for persistent game systems 
    /// </summary>
    public class GameSystems
    {
        
        //...
        public DataManager DataManager { get;  } 
        public  SceneLoader SceneLoader { get; }
        

        

        public GameSystems(DataManager dataManager)
        {
            DataManager = dataManager;
            SceneLoader = new SceneLoader();
            
            
        }


    }
}
